
class File {
	String filename;
	long length;
	public File(String filename,long length)
	{
		this.filename=filename;
		this.length = length;
	}
}
